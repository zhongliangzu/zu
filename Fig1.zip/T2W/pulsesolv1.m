function vals = pulsesolv1(w1, dw, kmw, mnotw, mnotm, R1W, R2W, R1M, R2M, init, duration)


    fm=mnotm;
    

   delter=0*2*pi;
D=1000;
lls=0;
for iii=1:1:D+1
    ls=sin(pi/2/D*(iii-1))*sqrt(2/pi)/abs(3*cos(pi/2/D*(iii-1))^2-1)/R2M*exp(-2*((dw-delter)/R2M/(3*cos(pi/2/D*(iii-1))^2-1))^2);
    ls=ls+lls;
       lls=ls;
 end
ls=ls/(D+1);
w=(w1)^2*pi*ls;
%w=w1^2*sqrt(pi/2)/R2M*exp(-((dw)/R2M*10)^2/2);
       A=[-R2W,    -dw,      0,             0 ,         0;             
          dw,      -R2W,     -w1,            0 ,         0 ;             
          0,       w1,     -R1W-fm*kmw,   kmw,         R1W  ;        
          0,         0,     fm*kmw,     -R1M-kmw-w ,    R1M*fm;     
          0,         0,      0,             0,          0;];

    [V,D] = eig(A); % Calculate Eigenvectors and Eigenvalues
    ppp = real(V*diag(exp(diag(D*duration)))/V)*init; % Calculate Matrix Exponential
vals=ppp;
    end

