function  p = pulsesim1(dw, kmw, mnotw, mnotm, R1W, R2W, R1M, R2M, duration, curve, angle, init, TR, exciteflag, excitewait, exciteduration, exciteangle)



init = pulsesolv1(0, 0, kmw, mnotw, mnotm, R1W, R2W, R1M, R2M, init, TR-duration);

w1=angle;
   init = pulsesolv1(w1, dw, kmw, mnotw, mnotm, R1W, R2W, R1M, R2M, init, duration);
   init(1)=0;
   init(2)=0;
 


ls=0.000014;
   for ttt=1:1:256
    ww1(ttt)=getsatpulse(curve, exciteangle, ttt, exciteduration, TR);
   end
  ww=sum((ww1).^2)*exciteduration/256*pi*ls; 
  
  
   ex=exciteangle/360*2*pi;
   init(2)=init(3)*sin(ex);
   init(3)=init(3)*cos(ex);
   init(4)=init(4)*exp(-ww);

p = init;





end